export interface Question {
  id: string;
  question: string;
  answer: string;
  productId: string;
}
