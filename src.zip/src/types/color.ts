export interface Color {
  id: string;
  name: string;
  productVariantId: string;
}
