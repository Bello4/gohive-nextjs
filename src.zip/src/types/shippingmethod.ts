export enum ShippingFeeMethod {
  ITEM = "ITEM",
  WEIGHT = "WEIGHT",
  FIXED = "FIXED",
}
