export interface Spec {
  id: string;
  name: string;
  value: string;
  productId: string;
  variantId: string;
}
