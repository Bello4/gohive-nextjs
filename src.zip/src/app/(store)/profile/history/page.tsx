import { redirect } from "next/navigation";

export default function ProfileHistoryPage() {
  redirect("/profile/history/1");
}
