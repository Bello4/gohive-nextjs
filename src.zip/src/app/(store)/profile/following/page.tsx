import { redirect } from "next/navigation";

export default function ProfileFollowingPage() {
  redirect("/profile/following/1");
}
