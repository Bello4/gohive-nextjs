export default function SendIcon() {
  return <div></div>;
}
