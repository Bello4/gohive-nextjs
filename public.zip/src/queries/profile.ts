export const getUserPayments = () => {
  return null;
};

export const getUserReviews = () => {
  return null;
};

export const getUserWishlist = () => {
  return null;
};

export const getUserOrders = () => {
  return null;
};

export const getUserFollowedStores = () => {
  // implementation
};
