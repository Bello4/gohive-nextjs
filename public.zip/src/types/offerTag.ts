export interface OfferTag {
  id: number;
  name: string;
  url: string;
}
