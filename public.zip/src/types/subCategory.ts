export interface SubCategory {
  id: number;
  name: string;
  image: string;
  url: string;
  featured: boolean;
  categoryId: number;
}
