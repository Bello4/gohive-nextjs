export type VariantImageType = {
  url: string;
  image: string;
};
