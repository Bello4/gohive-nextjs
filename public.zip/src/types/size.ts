export interface Size {
  id: string;
  size: string;
  quantity: string;
  price: string;
  discount: string;
  wishlist: string;
  productVariantId: string;
}
