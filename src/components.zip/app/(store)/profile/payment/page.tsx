// import PaymentsTable from "@/components/home/profile/payments/payments-table";
// import { getUserPayments } from "@/queries/profile";

export default function ProfilePaymentPage() {
  // const payments_data = await getUserPayments();
  // const { payments, totalPages } = payments_data;
  return (
    <div>
      {/* <PaymentsTable payments={payments} totalPages={totalPages} /> */}
      Payments
    </div>
  );
}
